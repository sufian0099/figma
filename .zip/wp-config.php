<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'figma' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '0kvWD65uB$!)9zkBIXj`M#jP5{I<|QhMMtHX?Mhe9I{YWqSk=;_#U!m3JQOppA(4' );
define( 'SECURE_AUTH_KEY',  'A 5rFTTV8`B.|^F`0pFq&g_sAWUO&d5y?.bBmQ?Z5E=]AYj8aYxpax*{E&zk7lf3' );
define( 'LOGGED_IN_KEY',    '+Pf_vQ(D9>Qkp?ZG?)tD<Mr<e-dB{~hARIPO(desd7F40LiMEU]y^w$2`JB %p[x' );
define( 'NONCE_KEY',        's)Y0!CErU8;RYUMu.JRY6`Jdvfi*hXE;,m=/Qg)gd{uWj7Gd,]fjSN8Pk,OlRvk%' );
define( 'AUTH_SALT',        'l2_[%W4^c>Gg]f^<O0Q,g)bEK<aFK!7G{d8*gCX!AO3&,MF~_Yx[}BVIdO6&a.8p' );
define( 'SECURE_AUTH_SALT', 'B{3G!_&PV!+ML49fg7ZK<T91>$jj<XpphCdg-^KtdYD{AS&rKN>R]1M[KrL]d,DB' );
define( 'LOGGED_IN_SALT',   '][pn^d)!8:@3tJo//,nkk~65smqQ%UO4lj(byC?eV]Q.cx6mJ?5Nmx7QVlbg-S?O' );
define( 'NONCE_SALT',       '9DOf-`RYb&TLv2w>|vn_[rxQG9&r(jnJN;D_4=zalLDrx9iF*b]OUls<[Eg>U`r8' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
